#!/bin/bash

./gnuplot.sh 'jeu_100_25_4_1.txt' 'jeu_100_25_4_1.eps'
./gnuplot.sh 'jeu_100_25_4_2.txt' 'jeu_100_25_4_2.eps'

./gnuplot.sh 'jeu_100_75_2_1.txt' 'jeu_100_75_2_1.eps'
./gnuplot.sh 'jeu_100_75_2_2.txt' 'jeu_100_75_2_2.eps'

./gnuplot.sh 'jeu_200_25_8_1.txt' 'jeu_200_25_8_1.eps'
./gnuplot.sh 'jeu_200_25_8_2.txt' 'jeu_200_25_8_2.eps'

./gnuplot.sh 'jeu_200_75_5_1.txt' 'jeu_200_75_5_1.eps'
./gnuplot.sh 'jeu_200_75_5_2.txt' 'jeu_200_75_5_2.eps'